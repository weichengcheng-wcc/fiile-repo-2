package cn.tdkpcw.example.html.common;

import cn.tdkpcw.example.html.model.form.FormReq;

import java.util.Vector;

/**
 * @author C.W
 * @date 2022/5/9 9:16
 * @desc form表单公共数据
 */
public class FormCommonData {

    /**
     * 存储前端提供的数据
     */
    public static Vector<FormReq> FORM_DATA = new Vector<>();

}
