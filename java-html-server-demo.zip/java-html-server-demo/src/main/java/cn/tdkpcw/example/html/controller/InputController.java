package cn.tdkpcw.example.html.controller;

import cn.tdkpcw.example.html.model.input.InputSubmitReq;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author C.W
 * @date 2022/5/12 7:03
 * @desc
 */
@Controller
@RequestMapping("html/input")
public class InputController {

    @GetMapping("index")
    public String index() {
        return "input";
    }

    @PostMapping("summit")
    public String submit(InputSubmitReq req, Model model) {
        model.addAttribute("data", req);
        return "input-submit";
    }

}
