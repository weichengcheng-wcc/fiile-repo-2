package cn.tdkpcw.example.html.controller;

import cn.tdkpcw.example.html.common.FormCommonData;
import cn.tdkpcw.example.html.model.form.FormReq;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author C.W
 * @date 2022/5/9 9:08
 * @desc form表单处理
 */
@Controller
@RequestMapping("html/form")
public class FormController {

    @GetMapping("index")
    public String index() {
        return "form";
    }

    @PostMapping("add")
    public String add(FormReq req) {
        FormCommonData.FORM_DATA.add(req);
        return "form";
    }

    @GetMapping("list")
    public String list(Model model) {
        model.addAttribute("list", FormCommonData.FORM_DATA);
        return "form-data";
    }

}
